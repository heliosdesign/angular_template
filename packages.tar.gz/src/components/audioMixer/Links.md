
[+](https://dvcs.w3.org/hg/audio/raw-file/tip/webaudio/specification.html) W3C Web Audio API spec

[+](https://developer.mozilla.org/en-US/docs/Web_Audio_API/Porting_webkitAudioContext_code_to_standards_based_AudioContext#Removal_of_the_synchronous_AudioContext.createBuffer_function) Porting webkitAudioContext code to standards based AudioContext - MDN